import react from 'react'
import { View, Text, FlatList, StyleSheet } from 'react-native'

export default function CarListComponent() {
    return (
        <View>
            <Text>Marca - Modelo</Text>
            <Text>Marca - Modelo</Text>
            <Text>Marca - Modelo</Text>
            <Text>Marca - Modelo</Text>
            <Text>Marca - Modelo</Text>
        </View>
    )
}